<?php
/*------------------------------------------------------------------------
 * Copyright (C) 2009 - 2012 The YouTech JSC. All Rights Reserved.
 * @license - GNU/GPL, http://www.gnu.org/licenses/gpl.html
 * Author: The YouTech JSC
 * Websites: http://www.magentech.com - http://www.cmsportal.net
-------------------------------------------------------------------------*/
// Incude class ThemeParameter, YtTheme
include_once (dirname(__FILE__).DS.'/includes/yt_theme.class.php');
// Include config
include_once (dirname(__FILE__).DS.'/yt_config_inc.php');
// Include Browser detect
include_once (dirname(__FILE__).DS.'/includes/browser.php');
